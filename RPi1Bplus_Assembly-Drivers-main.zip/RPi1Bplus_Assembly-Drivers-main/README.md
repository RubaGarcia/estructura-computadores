# RPi1B-_Assembly-Drivers
BerryClip and HC-SR04 sensor drivers programmed step by step in ARM assembly for Raspberry Pi model 1B+.
This repo also includes a final report for each project, in which I explain the steps I performed to get the full driver.
Projects final grades: 10/10
